package com.example.demo.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
//帖子
public class Post {
    private int postId; //帖子id
    private int userId; //发帖用户id
    private int bookID; //帖子对应的图书id
    private String title;   //标题
    private String content; //内容
    private String PostImg;    // 封面URL
    private LocalDateTime createTime;
}
