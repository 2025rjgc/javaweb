package com.example.demo.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
// 评论
public class Comment {
    private int userId;
    private int postId;
    private String comment;
    private LocalDateTime createTime;
}
